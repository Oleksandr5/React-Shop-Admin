// src/redux/actions/invoices.js
import firebase from "firebase";
export const UPDATE_INVOICES = "UPDATE_INVOICES";
export const UPDATE_INVOICES_SUMMARY = "UPDATE_INVOICES_SUMMARY";

export const fetchInvoices = (customerId) => {
	return async (dispatch) => {
		try {
			const snapshot = await firebase
				.database()
				.ref(`invoices/${customerId}`)
				.once("value");

			const data = snapshot.val();

			dispatch({
				type: UPDATE_INVOICES, // тут використовуємо константу
				payload: data ? Object.values(data) : []
			});
		} catch (error) {
			console.log(error);
		}
	};
};

export const fetchInvoicesSummary = (customerId) => {
	return async (dispatch) => {
		try {
			const snapshot = await firebase
				.database()
				.ref(`invoicesSummary/${customerId}`)
				.once("value");

			const data = snapshot.val();

			dispatch({
				type: UPDATE_INVOICES_SUMMARY, // тут теж
				payload: data ? Object.values(data) : []
			});
		} catch (error) {
			console.log(error);
		}
	};
};
