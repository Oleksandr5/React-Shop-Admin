import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import { fetchInvoices, fetchInvoicesSummary } from '../../../redux/actions/invoices'

const InvoicesPage = ({
	auth,
	invoices,
	summary,
	fetchInvoices,
	fetchInvoicesSummary
}) => {

	// Виклик екшенів при завантаженні або зміні auth
	useEffect(() => {
		if (auth?.uid) {
			fetchInvoices(auth.uid)
			fetchInvoicesSummary(auth.uid)
		}
	}, [auth, fetchInvoices, fetchInvoicesSummary])

	// Лог даних для перевірки
	useEffect(() => {
		console.log('Invoices data:', invoices)
		console.log('Invoices summary data:', summary)
	}, [invoices, summary])

	return (
		<div>
			<h2>Invoices</h2>

			{invoices.length === 0 && <p>No invoices yet.</p>}

			{invoices.map((invoice, index) => (
				<div key={index}>
					{invoice.number} - {invoice.total}
				</div>
			))}

			<h3>Summary</h3>
			{summary.length === 0 && <p>No summary yet.</p>}
			{summary.map((item, index) => (
				<div key={index}>
					{item.name} - {item.quantity} units
				</div>
			))}
		</div>
	)
}

const mapStateToProps = (state) => ({
	invoices: state.invoices.invoices,
	summary: state.invoices.summary,
	auth: state.auth
})

export default connect(mapStateToProps, {
	fetchInvoices,
	fetchInvoicesSummary
})(InvoicesPage)
