export const links = [
	{
		name: "Ваша накладна",
		to: "/invoices",
		exact: false,
		adminOnly: false
	},
	{
		name: "Накладні",
		to: "/invoices",
		exact: false,
		adminOnly: true
	}
];
